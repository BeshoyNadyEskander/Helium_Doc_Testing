package org.example.StepDefs;

import com.github.javafaker.Faker;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages.P01_register;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.Random;


public class D01_registerStepDefs {

    // create object from home design pattern of class registration
    P01_register register = new P01_register();
    Faker fake = new Faker();
    SoftAssert soft = new SoftAssert();
    String url ;
    String errorText;


    //step 1- navegate register page through click on register button
    @Given("user go to register page")
    public void Click_On_rigster_button()
    {
        register.register_Button.click();
    }

    //step 2 verify that signup page from url is https://stage2.stagefelbayt.com/signup/
    @Then("I should see the signup page")
    public void iShouldSeeTheSignupPage()
    {
        // should get current url and make assert on it
         url = Hooks.driver.getCurrentUrl();
        Assert.assertTrue(url.contains("signup/"));
    }
  // step 3 patient should enter valid his name
    @When("Patient writes his valid name")
    public void patientWritesHisValidName()
    {
              // I use faker dependency  to generate full name and store in config file
        String patientName = fake.name().fullName();

        // calling web element of patient name exiting in home design pattern
        register.FullNameOfPatient.sendKeys(patientName);
        configuration.set("validFullName",patientName);

    }

    // step 4 patient should enter his valid number phone
    @And("Patient fills his valid number phone {string}")
    public void patientFillsHisValidNumberPhone(String numberPhone)
    {
        // use config file to get number and we should change phone when we run registeration
        numberPhone = configuration.get("validPhoneNumber");

      //  numberPhone = fake.phoneNumber().phoneNumber();
        register.phone_number().sendKeys(numberPhone);
        configuration.set("validPhoneNumber", numberPhone);

    }

    // step 5 user should enter his valid email
    @And("patient enter valid Email")
    public void patientEnterValidEmail()
    {
        // I use faker dependency  to generate Email and store in config file

        String  random_Email = fake.internet().safeEmailAddress();
        register.Email_of_patient.sendKeys(random_Email);
        configuration.set("validEmail",random_Email);
    }


    // step 6 user should enter valid password
    @And("Patient enter valid password")
    public void patientEnterValidPassword()
    {
        String validPassword = fake.internet().password();
        register.enter_password_of_patient.sendKeys(validPassword);
        configuration.set("validPassword",validPassword);
    }

    //step 7 user click on sign up to create new account
    @And("patient press on create on account button")
    public void patientPressOnCreateOnAccountButton() throws InterruptedException {
        Thread.sleep(2000);

        register.click_on_create_new_account_button.click();

    }

    @Then("I should see Verify your Number")
    public void iShouldSee_number_phone() throws InterruptedException {

        boolean status_number_phone = register.verify_phone_number().isDisplayed();
        Assert.assertTrue(status_number_phone);

    }

    @When("I fill in PIN {string}")
    public void iFillInPIN(String pin) {
        pin= register.PIN;
        register.enter_pin.sendKeys(pin);
    }

    @And("I click on Verify your Number")
    public void iClickOnVerifyYourNumber() throws InterruptedException {
        register.enter_verify_your_number_button.click();
        Thread.sleep(2000);

    }

    @Then("verify that patient logged in successfully")
    public void verifyThatPatientLoggedInSuccessfully() {

        // verify home page through ulr is https://stage2.stagefelbayt.com/
         url = Hooks.driver.getCurrentUrl();
        soft.assertEquals(url,"https://stage2.stagefelbayt.com/");
     soft.assertAll();
    }

    // verify that patient could not sign up with using old email
    @And("patient enter old Email {string}")
    public void patientEnterOldEmail(String old_email)
    {
        old_email = configuration.get("storedEmail");
        register.Email_of_patient.sendKeys(old_email);
    }

    // verify that error message of old email is displayed
    @Then("verify that error message {string} is displayed")
    public void verifyThatErrorMessageIsDisplayed(String errorMessage)
    {
       errorText = register.errorMessage.getText();
      soft.assertEquals(errorMessage,errorText);

      // color of error message is red
        String color = register.errorMessage.getCssValue("background-color");
        String colorHex = Color.fromString(color).asHex();
        soft.assertEquals(colorHex,"#f81e46");
      soft.assertAll();

    }

    @And("Patient fills his old number phone {string}")
    public void patientFillsHisOldNumberPhone(String old_number_phone)
    {
          old_number_phone = configuration.get("storedPhoneNumber");
          register.phone_number().sendKeys(old_number_phone);
    }

    // ensure the error message of phone number is displayed
    @Then("verify that error message of phone {string} is displayed")
    public void verifyThatErrorMessageOfPhoneIsDisplayed(String Error_message_number_phone)
    {
         errorText = register.errorMessage.getText();
        soft.assertEquals(Error_message_number_phone,errorText);
        // color of error message is red
        String color = register.errorMessage.getCssValue("background-color");
        String colorHex = Color.fromString(color).asHex();
        soft.assertEquals(colorHex,"#f81e46");
        soft.assertAll();

    }
     //
    @And("Patient fills his new number phone {string}")
    public void patientFillsHisNewNumberPhone(String new_phonee_number) {

        new_phonee_number =configuration.get("newPhoneNumber");
        register.phone_number().sendKeys(new_phonee_number);

    }
       // verify that url is https://stage2.stagefelbayt.com/signup/   >>>when user enter new phone without email
    @Then("verify that patient should not log in home page")
    public void verifyThatPatientShouldNotLogInHomePage()
    {
        url=Hooks.driver.getCurrentUrl();
        soft.assertTrue(url.contains("signup/"));
        soft.assertAll();
    }

    @And("patient should see error massage {string}")
    public void patientShouldSeeErrorMassage(String errorMessage_fill_email)
    {
         errorText = register.errorMessage.getText();
        soft.assertEquals(errorMessage_fill_email,errorText);
        soft.assertAll();
    }

    @And("patient should see error massage for forgetting password {string}")
    public void patientShouldSeeErrorMassageForForgettingPassword(String errorMessageForPassword) {

         errorText = register.errorMessage.getText();
        Assert.assertNotEquals(errorMessageForPassword,errorText);
    }
}
