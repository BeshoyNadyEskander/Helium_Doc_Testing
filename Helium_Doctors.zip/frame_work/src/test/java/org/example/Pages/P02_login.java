package org.example.Pages;

import org.example.StepDefs.Hooks;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class P02_login {

    public P02_login()
    {
        PageFactory.initElements(Hooks.driver,this);
    }

    public  String url_login()
    {
        return Hooks.driver.getCurrentUrl();
    }

    //1- element of login button
    @FindBy(css = "a[href=\"/login/\"]")
    public WebElement login_button;

    //2- element of login with email button
    @FindBy(xpath = "//*[contains(text(), \"With Email\")]")
    public WebElement login_with_email_button;

    //3- element of patient could write his email
    @FindBy(css = "input[name=\"email\"]")
    public WebElement patient_enter_email;

    //4-element of patient could write his password
    @FindBy(css = "input[name=\"password\"]")
    public WebElement Patient_enter_password;

    //5- element of login button for clicking on to logged in his account
    @FindBy(css = "input[name=\"sign_in\"]")
    public WebElement click_on_login_button;

    //6- element of drop down menu
    @FindBy(css = "div[class=\"collapse navbar-collapse navbar-right additional-items desk-only\"] ul[class=\"nav navbar-nav\"]")
    public WebElement drop_down_list;

 //7- element of error message
    @FindBy(css = "div[class=\"alert alert-block alert-danger inherit-width\"]")
    public WebElement error_message;

    //8- element of with phone butto to could login through phone number
    @FindBy(css = "li[class=\"tab-titles active\"]")
    public WebElement click_on_with_phone_button;

    //9- element of number phone to could write on it
    @FindBy(css = "input[placeholder=\"Add your Mobile Number\"]")
    public WebElement enter_stored_number_phone;

    @FindBy(css = "input[name=\"login_btn\"]")
    public WebElement press_login;

    @FindBy(css = "input[placeholder=\"Enter Password\"]")
    public WebElement enter_stored_password;

    @FindBy(css = "div[class=\"alert alert-block alert-danger inherit-width\"]")
    public WebElement error_message_numberPhone;
}
