package org.example.StepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages.P03_search;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.Random;

public class D03_searchStepDefs {

    P03_search search = new P03_search();
    boolean status;

    public static String specialist_text;

    public static String name_spacialist;

    String error_message;

    String url;
    WebDriverWait wait = new WebDriverWait(Hooks.driver, Duration.ofSeconds(10));

    @When("patient click on speciality button")
    public void patient_click_on_search_label()
    {
        //click on button_of_speciality to choose from it
        search.button_of_speciality.click();
    }

    @Then("verify that list of specialities is displayed")
    public void verifyThatListOfSpecialitiesIsDisplayed()
    {
        // ensure that dropdown List is displayed 
       status = search.dropdown_search.isDisplayed();
        Assert.assertTrue(status);
    }

    @When("patient could click on specialist")
    public void patientCouldClickOnSpecialist() throws InterruptedException {
        // count for specialities
        int count_number_specialities = search.list_of_specialists.size();

        //2- generate random number from list
        int random_number_specalities = new Random().nextInt(count_number_specialities);
        System.out.println(random_number_specalities);

    // 3- hover on your random selecting about using class Actions
        Actions action = new Actions(Hooks.driver);
        action.moveToElement(search.list_of_specialists.get(random_number_specalities)).perform();

   //4- select specialist
       specialist_text= search.list_of_specialists.get(random_number_specalities).getText().trim();
        System.out.println(specialist_text);
       // click on random
        search.list_of_specialists.get(random_number_specalities).click();
          Thread.sleep(3000);

    }

    @And("patient click on search button")
    public void patientClickOnSearchButton() throws InterruptedException {
        // click on search button to navigate the speciality
       wait.until(ExpectedConditions.elementToBeClickable(search.click_on_search_button)).click();
       Thread.sleep(2000);

    }


    @Then("verify that patient could find doctors relative specialty who is chosen")
    public void verifyThatPatientCouldFindDoctorsRelativeSpecialtyWhoIsChosen()
    {
        if (!search.titles_of_specialist(specialist_text).isEmpty()) {

            // count number of  doctors relative to title specialist that is chosen by random
            int count_title_of_specialist = search.titles_of_specialist(specialist_text).size();
            for (int i = 0; i < count_title_of_specialist; i++) {
                 name_spacialist = search.titles_of_specialist(specialist_text).get(count_title_of_specialist).getText();
                // ensure that random specialty is true

            }
            Assert.assertTrue(specialist_text.toLowerCase().contains(name_spacialist.toLowerCase()));

        }



    }

}
