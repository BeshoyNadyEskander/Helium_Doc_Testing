package org.example.StepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages.P02_login;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;

public class D02_loginStepDefs
{
    P02_login login = new P02_login();
    String error_text;

   WebDriverWait wait = new WebDriverWait(Hooks.driver, Duration.ofSeconds(10));

    @Given("patient navigate to login page")
    public void click_on_login_button()
    {
        // clcik on login button to navigate login page
        login.login_button.click();
    }
    @Then("patient should see the login page")
    public void patientShouldSeeTheLoginPage()
    {
        // assert login page appears to patient about url is https://stage2.stagefelbayt.com/login/
        Assert.assertTrue(login.url_login().contains("login/"));

    }

    @When("patient click on with Email")
    public void patientClickOnWithEmail()
    {
        // click on with email button to patient could login with email and password
        login.login_with_email_button.click();
    }

    @And("patient fill in email address {string}")
    public void patientFillInEmailAddress(String stored_email)
    {
        // use data (stored email) from config file
        stored_email =configuration.get("storedEmail");

        //patient could write his email
        login.patient_enter_email.sendKeys(stored_email);
    }

    @And("patient fill in password {string}")
    public void patientFillInPassword(String stored_password)
    {
        // use data (stored password) from config file
        stored_password=configuration.get("stordPassword");

        ///patient could write his password
        login.Patient_enter_password.sendKeys(stored_password);
    }

    @And("patient click on Log in")
    public void patientClickOnLogIn()
    {
       login.click_on_login_button.click();
    }

    @Then("patient should see homepage")
    public void patientShouldSeeHomepage() throws InterruptedException {
        // assert on drop down menu is displayed
        boolean status = login.drop_down_list.isDisplayed();
        Assert.assertTrue(status);

        Thread.sleep(2000);
        //assert on url of home page is https://stage2.stagefelbayt.com/
        wait.until(ExpectedConditions.urlToBe(login.url_login()));

    }

    @And("patient fill in unstored email address {string}")
    public void patientFillInUnstoredEmailAddress(String unstored_email)
    {
        //use unstored email from config file
        unstored_email =configuration.get("unStoredEmail");
        //patient writes un store email
        login.patient_enter_email.sendKeys(unstored_email);
    }

    @Then("patient should see error massage Email and password are not correct")
    public void patientShouldSeeErrorMassageEmailAndPasswordAreNotCorrect()
    {
        // aseert on error message includes Email and password are not correct
        error_text= login.error_message.getText();
        Assert.assertTrue(error_text.contains("Email and password are not correct"));

        // Assert on color about background of error mess is red
        String color = login.error_message.getCssValue("background-color");
        String colorHEX = Color.fromString(color).asHex();
        Assert.assertEquals(colorHEX,"#f81e46");
    }

    @When("patient click on with phone")
    public void patientClickOnWithPhone()
    {   //patient could log in through phone number
        login.click_on_with_phone_button.click();

    }

    @And("patient fill phone number for his account {string}")
    public void patientFillPhoneNumberForHisAccount(String stored_number_phone)
    {
        stored_number_phone= configuration.get("storedPhoneNumber");
        login.enter_stored_number_phone.sendKeys(stored_number_phone);
    }

    @And("patient click on Login button")
    public void patientClickOnLoginButton()
    {
        // click on login button
        login.press_login.click();
    }

    @When("patient enter in password {string}")
    public void patientEnterInPassword(String stored_Password)
    {
        stored_Password=configuration.get("stordPassword");
        login.enter_stored_password.sendKeys(stored_Password);
    }


    @And("patient fill unstored phone number for his account {string}")
    public void patientFillUnstoredPhoneNumberForHisAccount(String unstored_phone)
    {
        // generate data of unstored phone number from config file
        unstored_phone=configuration.get("unStoredPhoneNumber");
        login.enter_stored_number_phone.sendKeys(unstored_phone);
    }


    @Then("patient should see the error message {string}")
    public void patientShouldSeeTheErrorMessageUserDoesnTExist(String error_message_phone)
    {
      boolean status=  login.error_message_numberPhone.isDisplayed();
        Assert.assertTrue(status);
        Assert.assertEquals(login.error_message_numberPhone.getText(),error_message_phone);


    }
}
