package org.example.StepDefs;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Hooks {


    public static WebDriver driver =null;

    @Before
    public void openBrowser()
    {

        //step 1 setup google chrome
        WebDriverManager.chromedriver().setup();

        //step 2 define value for driver
        driver = new ChromeDriver();

        //step 3 maximize for window of site
        driver.manage().window().maximize();

        //step 4 use implicate wait to wait elements load on dom page
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        //step 5 navigate to url of web site (Helium Doc)
        driver.navigate().to("https://stage2.stagefelbayt.com/");

    }
    // close browser
    @After
    public void quitDriver() throws InterruptedException {
        Thread.sleep(2000);
        driver.quit();
    }

}
