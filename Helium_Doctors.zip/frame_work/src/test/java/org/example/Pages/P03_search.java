package org.example.Pages;

import org.example.StepDefs.Hooks;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class P03_search
       {

    public P03_search()
    {
        PageFactory.initElements(Hooks.driver,this);
    }

    // eleent of label of search for speciality
    @FindBy(xpath = "//div[@class=\"sc-d5c72ba6-1 czZxLy\"]//*[contains(text(),'Select Speciality')]")
    public WebElement button_of_speciality;

      // element of Specialty-dropdown-search is displayed
      @FindBy(css = "input[data-cy=\"Specialty-dropdown-search-input\"]")
      public WebElement dropdown_search;

      // list of elements for categories of specialists
           @FindBy(css = "div[role=\"listbox\"] ul[role=\"group\"] [role=\"option\"]")
           public List<WebElement> list_of_specialists;

           // element of search button
           @FindBy(xpath = "//*[@data-cy=\"hero-cta\"]")
           public WebElement click_on_search_button;

           public static void current_url()
           {
                Hooks.driver.getCurrentUrl();
           }

           public static  List<WebElement> titles_of_specialist(String name)
           {

               // dont forget add single quotes to pass string parameter
              return Hooks.driver.findElements(By.xpath("//*[@id=\"name-group\"]//*[contains(text(),\'"+name+" \')]"));

           }
           @FindBy(css = "div[id=\"findDoctors\"]")
           public WebElement message_for_not_find_doctors_relative_spaciality;


       }



