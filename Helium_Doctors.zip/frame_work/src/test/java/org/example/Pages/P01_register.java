package org.example.Pages;

import org.example.StepDefs.Hooks;
import org.example.StepDefs.configuration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class P01_register {

    public static String PIN = "1234";
    public P01_register()
    {
        PageFactory.initElements(Hooks.driver,this);
    }

    //1- element of rigster button on home page of Helium Doc
    @FindBy(css = "a[class=\"nav-link signup\"]")
    public WebElement register_Button;


    //2- element of name of patient
    @FindBy(css = "input[placeholder=\"Full Name\"]")
    public WebElement FullNameOfPatient;

    //3- element of phone number


    public WebElement phone_number()
    {
     return Hooks.driver.findElement(By.cssSelector("input[placeholder=\"Enter your Mobile Number\"]"));

    }

    //4- element of email of patient
    @FindBy(css ="input[name=\"email\"]")
    public WebElement Email_of_patient;

    //5- element of password
    @FindBy (css = "input[id=\"id_password\"]")
    public WebElement enter_password_of_patient;

    //6- element of create new account button
    @FindBy(xpath = "//input[@value=\"Create your account\"]")
    public WebElement click_on_create_new_account_button;

    //7- element of verify number phone
    public WebElement verify_phone_number()
    {
        // use number phone is stored in config file to make assert on it
        return Hooks.driver.findElement(By.xpath("//*[contains(text(), \""+configuration.get("validPhoneNumber")+"\" )]"));
    }

//8- element of pin number
    @FindBy(css = "input[placeholder=\"Enter your PIN Number\"]")
    public WebElement enter_pin;

    //9- element of verify number button
    @FindBy(css = "input[value=\"Verify your Number\"]")
    public WebElement enter_verify_your_number_button;

    //10- element of error message of old email / old number
    @FindBy(xpath = "//div[@class=\"alert alert-block alert-danger inherit-width\"]")
    public WebElement errorMessage;

}
